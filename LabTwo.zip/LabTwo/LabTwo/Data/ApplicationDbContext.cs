﻿using Microsoft.EntityFrameworkCore;
using LabTwo.Models;
using System.Collections.Generic;

namespace LabTwo.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
    }
}
